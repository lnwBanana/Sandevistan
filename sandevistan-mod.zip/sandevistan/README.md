# Sandevistan (Fabric 1.21.11)

Mod สไตล์ Cyberpunk Edgerunners — ผ่าตัดฝังที่กระดูกสันหลัง, ใช้แล้วเวลารอบตัวช้าลง, มีร่าง afterimage ซ้อนกันไล่สี

## Build
Java 21 แล้วรัน:
    ./gradlew build        (Windows: gradlew.bat build)
ไฟล์จะอยู่ที่ build/libs/sandevistan-1.0.0.jar  (ใช้ไฟล์ที่ไม่มี -sources)
ทดสอบในเกม: ./gradlew runClient
ต้องลง Fabric Loader 0.20.1+ และ Fabric API 0.141.6+1.21.11

## วิธีเล่น
1. ได้ไอเทม Sandevistan Implant: craft (netherite x4, redstone block x2, diamond x2, eye of ender กลาง — ช่องรูปแบบ NRN/DED/NRN) หรือ /give @s sandevistan:sandevistan_implant
2. ถือแล้ว **กดค้างคลิกขวา 8 วินาที** = ผ่าตัด (เสียเลือด, มึน, ตาพร่า, หัวใจเต้น) ต้องมีเลือด > 5 หัวใจ
3. ติดตั้งแล้วถาวร (รอดตาย) กด **V** เปิด/ปิด, กด **B** เปลี่ยนชุดสี afterimage
4. ใช้นานเกิน ~16 วิ = ร้อนเกิน (เลือดกำเดา/มึน/ตาบอด/อ่อนแรง) ต้องรอเย็นลง

## ไฟล์ที่เสี่ยงต้องแก้ถ้า compile ไม่ผ่าน (เขียนโดยไม่ได้ compile จริง)
- client/render/AfterimageRenderer.java  (extractEntity, submit, ชื่อ field ของ render state)
- client/mixin/LivingEntityRendererMixin.java (ถ้า mixin ไม่ติด afterimage จะเป็นสีขาวจางๆ แทนสี)
