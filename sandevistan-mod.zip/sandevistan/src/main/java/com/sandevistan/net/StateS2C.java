package com.sandevistan.net;

import java.util.UUID;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

import com.sandevistan.SandevistanMod;

/** Server -> Client : สถานะ Sandevistan ของผู้เล่นคนหนึ่ง (ไว้วาด afterimage + HUD) */
public record StateS2C(UUID player, boolean active, float strain01, int cooldownTicks, boolean overheated)
	implements CustomPacketPayload {
	public static final CustomPacketPayload.Type<StateS2C> TYPE =
		new CustomPacketPayload.Type<>(SandevistanMod.id("state"));

	public static final StreamCodec<RegistryFriendlyByteBuf, StateS2C> CODEC = StreamCodec.of(
		(buf, p) -> {
			buf.writeUUID(p.player());
			buf.writeBoolean(p.active());
			buf.writeFloat(p.strain01());
			buf.writeVarInt(p.cooldownTicks());
			buf.writeBoolean(p.overheated());
		},
		buf -> new StateS2C(buf.readUUID(), buf.readBoolean(), buf.readFloat(), buf.readVarInt(), buf.readBoolean())
	);

	@Override
	public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
