package com.sandevistan.net;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

import com.sandevistan.server.SandevistanManager;

public final class ModNetwork {
	public static void init() {
		PayloadTypeRegistry.playC2S().register(ActivateC2S.TYPE, ActivateC2S.CODEC);
		PayloadTypeRegistry.playS2C().register(StateS2C.TYPE, StateS2C.CODEC);

		ServerPlayNetworking.registerGlobalReceiver(ActivateC2S.TYPE,
			(payload, context) -> SandevistanManager.toggle(context.player()));
	}

	private ModNetwork() {}
}
