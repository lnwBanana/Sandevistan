package com.sandevistan.net;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

import com.sandevistan.SandevistanMod;

/** Client -> Server : กดปุ่มเปิด/ปิด Sandevistan */
public record ActivateC2S() implements CustomPacketPayload {
	public static final CustomPacketPayload.Type<ActivateC2S> TYPE =
		new CustomPacketPayload.Type<>(SandevistanMod.id("activate"));
	public static final StreamCodec<RegistryFriendlyByteBuf, ActivateC2S> CODEC =
		StreamCodec.unit(new ActivateC2S());

	@Override
	public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
