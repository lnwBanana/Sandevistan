package com.sandevistan.server;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;

import com.sandevistan.Fx;
import com.sandevistan.ModAttachments;
import com.sandevistan.net.StateS2C;

/**
 * ตรรกะ Sandevistan ฝั่งเซิร์ฟเวอร์
 *  - ผู้ใช้: Speed/Haste/Jump สูง
 *  - สิ่งมีชีวิตรอบๆ: โดนหน่วงหนัก (เหมือนเวลาช้าลง) + กระสุน/ลูกธนูช้าลง
 *  - "strain" สะสมตอนใช้งาน เต็มแล้วร้อนเกิน (เลือดกำเดา/มึน/ตาบอด) ต้องรอเย็นลง
 */
public final class SandevistanManager {
	private static final float STRAIN_PER_TICK = 100.0F / (20 * 16); // ใช้ต่อเนื่อง ~16 วิ จะร้อนเกิน
	private static final float STRAIN_DECAY = 0.12F;
	private static final int COOLDOWN = 40;
	private static final int OVERHEAT_COOLDOWN = 20 * 12;
	private static final double RADIUS = 28.0;

	private static final Map<UUID, Data> DATA = new HashMap<>();

	private static final class Data {
		boolean active;
		boolean overheated;
		float strain;
		int cooldown;
		int tick;
		boolean dirty;
	}

	public static void init() {
		ServerTickEvents.END_SERVER_TICK.register(SandevistanManager::tick);
		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> DATA.remove(handler.getPlayer().getUUID()));
	}

	public static boolean isActive(ServerPlayer player) {
		Data d = DATA.get(player.getUUID());
		return d != null && d.active;
	}

	/** เรียกเมื่อผู้เล่นกดปุ่ม */
	public static void toggle(ServerPlayer player) {
		if (!ModAttachments.isInstalled(player)) {
			player.displayClientMessage(Component.literal("§cคุณยังไม่ได้ฝัง Sandevistan"), true);
			return;
		}
		Data d = DATA.computeIfAbsent(player.getUUID(), k -> new Data());
		if (d.active) {
			stop(player, d, false);
			return;
		}
		if (d.overheated) {
			player.displayClientMessage(Component.literal("§cระบบร้อนเกินไป รอให้เย็นลงก่อน"), true);
			return;
		}
		if (d.cooldown > 0) {
			player.displayClientMessage(Component.literal("§eระบบยังไม่พร้อม"), true);
			return;
		}
		d.active = true;
		d.dirty = true;
		player.playSound(SoundEvents.BEACON_ACTIVATE, 1.2F, 2.0F);
		player.playSound(SoundEvents.LIGHTNING_BOLT_THUNDER, 0.4F, 2.0F);
	}

	private static void stop(ServerPlayer player, Data d, boolean overheat) {
		d.active = false;
		d.dirty = true;
		d.cooldown = overheat ? OVERHEAT_COOLDOWN : COOLDOWN;
		player.playSound(SoundEvents.BEACON_DEACTIVATE, 1.0F, 1.6F);
		if (overheat) {
			d.overheated = true;
			ServerLevel level = (ServerLevel) player.level();
			player.addEffect(Fx.eff("nausea", 240, 0));
			player.addEffect(Fx.eff("blindness", 80, 0));
			player.addEffect(Fx.eff("slowness", 240, 1));
			player.addEffect(Fx.eff("weakness", 240, 1));
			if (player.getHealth() > 8.0F) {
				player.hurtServer(level, level.damageSources().generic(), 6.0F);
			}
			player.playSound(SoundEvents.PLAYER_HURT, 1.0F, 0.6F);
			player.displayClientMessage(Component.literal("§4§lร้อนเกินพิกัด! §r§cเลือดกำเดาไหล ระบบถูกตัดอัตโนมัติ"), true);
		}
	}

	private static void tick(MinecraftServer server) {
		for (ServerPlayer player : server.getPlayerList().getPlayers()) {
			boolean installed = ModAttachments.isInstalled(player);
			Data d = DATA.get(player.getUUID());
			if (d == null) {
				if (!installed) continue;
				d = new Data();
				DATA.put(player.getUUID(), d);
			}
			if (!installed) {
				if (d.active) stop(player, d, false);
				continue;
			}

			d.tick++;
			if (d.active) {
				d.strain += STRAIN_PER_TICK;
				applyUserBuffs(player);
				slowSurroundings(player);
				if (d.strain >= 100.0F) {
					d.strain = 100.0F;
					stop(player, d, true);
				}
			} else {
				if (d.cooldown > 0) d.cooldown--;
				if (d.strain > 0) d.strain = Math.max(0.0F, d.strain - STRAIN_DECAY);
				if (d.overheated && d.strain <= 35.0F) d.overheated = false;
			}

			if (d.dirty || (d.active && d.tick % 3 == 0) || d.tick % 10 == 0) {
				broadcast(player, d);
				d.dirty = false;
			}
		}
	}

	private static void applyUserBuffs(ServerPlayer player) {
		player.addEffect(Fx.eff("speed", 6, 5));
		player.addEffect(Fx.eff("haste", 6, 3));
		player.addEffect(Fx.eff("jump_boost", 6, 1));
		player.addEffect(Fx.eff("resistance", 6, 1));
	}

	private static void slowSurroundings(ServerPlayer player) {
		ServerLevel level = (ServerLevel) player.level();
		for (Entity e : level.getEntitiesOfClass(Entity.class, player.getBoundingBox().inflate(RADIUS),
			x -> x != player && x.isAlive())) {
			if (e instanceof ServerPlayer other && isActive(other)) continue; // Sandevistan คนอื่นไม่โดนหน่วง
			if (e instanceof Projectile projectile) {
				projectile.setDeltaMovement(projectile.getDeltaMovement().scale(0.6));
			} else if (e instanceof LivingEntity living) {
				living.addEffect(Fx.eff("slowness", 8, 5));
			}
		}
	}

	private static void broadcast(ServerPlayer player, Data d) {
		StateS2C packet = new StateS2C(player.getUUID(), d.active, d.strain / 100.0F, d.cooldown, d.overheated);
		ServerLevel level = (ServerLevel) player.level();
		for (ServerPlayer other : level.players()) {
			if (other == player || other.distanceToSqr(player) < 160.0 * 160.0) {
				ServerPlayNetworking.send(other, packet);
			}
		}
	}

	private SandevistanManager() {}
}
