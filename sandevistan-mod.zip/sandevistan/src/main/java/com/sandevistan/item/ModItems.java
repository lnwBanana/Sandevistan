package com.sandevistan.item;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;

import com.sandevistan.SandevistanMod;

public final class ModItems {
	public static final ResourceKey<Item> IMPLANT_KEY =
		ResourceKey.create(Registries.ITEM, SandevistanMod.id("sandevistan_implant"));

	public static final Item IMPLANT = Registry.register(
		BuiltInRegistries.ITEM, IMPLANT_KEY,
		new SandevistanImplantItem(new Item.Properties().setId(IMPLANT_KEY).stacksTo(1).rarity(Rarity.EPIC))
	);

	public static void init() {
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES)
			.register(entries -> entries.accept(IMPLANT));
	}

	private ModItems() {}
}
