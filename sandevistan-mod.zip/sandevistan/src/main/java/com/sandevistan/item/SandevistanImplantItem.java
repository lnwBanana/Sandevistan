package com.sandevistan.item;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUseAnimation;
import net.minecraft.world.level.Level;

import com.sandevistan.Fx;
import com.sandevistan.ModAttachments;

/**
 * ชุดผ่าตัดฝัง Sandevistan: กดค้างคลิกขวา 8 วินาที
 * ระหว่างผ่าตัดจะเสียเลือดเป็นช่วงๆ + มีข้อความ/เสียง/อาการมึนงง จบแล้วถึงจะติดตั้งถาวร
 */
public class SandevistanImplantItem extends Item {
	public static final int SURGERY_TICKS = 160;

	public SandevistanImplantItem(Properties properties) {
		super(properties);
	}

	@Override
	public InteractionResult use(Level level, Player player, InteractionHand hand) {
		if (ModAttachments.isInstalled(player)) {
			if (!level.isClientSide()) {
				player.displayClientMessage(Component.literal("§bคุณมี Sandevistan ฝังอยู่แล้ว"), true);
			}
			return InteractionResult.FAIL;
		}
		if (player.getHealth() <= 10.0F && !player.getAbilities().instabuild) {
			if (!level.isClientSide()) {
				player.displayClientMessage(Component.literal("§cร่างกายอ่อนแอเกินไป เลือดต้องเกิน 5 หัวใจก่อนผ่าตัด"), true);
			}
			return InteractionResult.FAIL;
		}
		player.startUsingItem(hand);
		return InteractionResult.CONSUME;
	}

	@Override
	public int getUseDuration(ItemStack stack, LivingEntity entity) {
		return SURGERY_TICKS;
	}

	@Override
	public ItemUseAnimation getUseAnimation(ItemStack stack) {
		return ItemUseAnimation.BOW;
	}

	@Override
	public void onUseTick(Level level, LivingEntity entity, ItemStack stack, int remaining) {
		if (!(level instanceof ServerLevel server) || !(entity instanceof ServerPlayer player)) return;
		int elapsed = SURGERY_TICKS - remaining;

		// ตรึงผู้เล่นไว้ระหว่างผ่าตัด
		player.addEffect(Fx.eff("slowness", 5, 4));

		switch (elapsed) {
			case 2 -> {
				player.displayClientMessage(Component.literal("§7กรีดผิวหนังตามแนวกระดูกสันหลัง..."), true);
				player.playSound(SoundEvents.PLAYER_HURT, 1.0F, 0.7F);
				hurt(server, player, 2.0F);
			}
			case 40 -> {
				player.displayClientMessage(Component.literal("§cเปิดช่องกระดูกสันหลัง..."), true);
				player.addEffect(Fx.eff("nausea", 200, 0));
				player.playSound(SoundEvents.ANVIL_USE, 0.6F, 1.6F);
				hurt(server, player, 2.0F);
			}
			case 80 -> {
				player.displayClientMessage(Component.literal("§bเสียบ Spinal Rail เข้าระหว่างข้อกระดูก..."), true);
				player.playSound(SoundEvents.ANVIL_PLACE, 0.8F, 1.9F);
				hurt(server, player, 3.0F);
			}
			case 120 -> {
				player.displayClientMessage(Component.literal("§dเชื่อมต่อระบบประสาทกับ Sandevistan..."), true);
				player.addEffect(Fx.eff("blindness", 40, 0));
				player.playSound(SoundEvents.WARDEN_HEARTBEAT, 1.5F, 1.2F);
				hurt(server, player, 2.0F);
			}
			default -> {
				if (elapsed % 20 == 10) {
					player.playSound(SoundEvents.WARDEN_HEARTBEAT, 1.0F, 1.0F + elapsed / 200.0F);
				}
			}
		}
	}

	@Override
	public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
		if (level instanceof ServerLevel && entity instanceof ServerPlayer player) {
			ModAttachments.setInstalled(player, true);
			player.addEffect(Fx.eff("nausea", 120, 0));
			player.addEffect(Fx.eff("weakness", 200, 0));
			player.playSound(SoundEvents.BEACON_ACTIVATE, 1.0F, 1.8F);
			player.playSound(SoundEvents.LIGHTNING_BOLT_THUNDER, 0.5F, 2.0F);
			player.displayClientMessage(Component.literal("§b§lSANDEVISTAN §r§bติดตั้งสำเร็จ — กดปุ่ม V เพื่อเปิดใช้งาน"), true);
			if (!player.getAbilities().instabuild) {
				stack.shrink(1);
			}
		}
		return stack;
	}

	private static void hurt(ServerLevel level, ServerPlayer player, float amount) {
		// ไม่ให้ตายจากการผ่าตัด
		if (player.getHealth() > amount + 2.0F) {
			player.hurtServer(level, level.damageSources().generic(), amount);
		}
	}
}
