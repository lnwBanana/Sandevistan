package com.sandevistan;

import com.mojang.serialization.Codec;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentSyncPredicate;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.world.entity.player.Player;

/** เก็บสถานะ "ผู้เล่นผ่าตัดฝัง Sandevistan แล้ว" แบบถาวร (รอดตาย + sync ไปทุก client) */
public final class ModAttachments {
	public static final AttachmentType<Boolean> INSTALLED = AttachmentRegistry.<Boolean>create(
		SandevistanMod.id("installed"),
		builder -> builder
			.persistent(Codec.BOOL)
			.copyOnDeath()
			.initializer(() -> false)
			.syncWith(ByteBufCodecs.BOOL, AttachmentSyncPredicate.all())
	);

	public static boolean isInstalled(Player player) {
		Boolean v = player.getAttached(INSTALLED);
		return v != null && v;
	}

	public static void setInstalled(Player player, boolean value) {
		player.setAttached(INSTALLED, value);
	}

	public static void init() {
		// โหลดคลาสเพื่อ register attachment
	}

	private ModAttachments() {}
}
