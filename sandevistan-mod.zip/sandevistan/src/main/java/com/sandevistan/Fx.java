package com.sandevistan;

import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;

/** ดึง effect ด้วยชื่อ id ("speed", "slowness", ...) กันปัญหาชื่อ constant เปลี่ยนตามเวอร์ชัน */
public final class Fx {
	public static MobEffectInstance eff(String path, int duration, int amplifier) {
		Holder<MobEffect> holder = BuiltInRegistries.MOB_EFFECT
			.get(Identifier.withDefaultNamespace(path)).orElseThrow();
		return new MobEffectInstance(holder, duration, amplifier, false, false, false);
	}

	private Fx() {}
}
