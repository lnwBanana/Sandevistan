package com.sandevistan;

import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;

import com.sandevistan.item.ModItems;
import com.sandevistan.net.ModNetwork;
import com.sandevistan.server.SandevistanManager;

public class SandevistanMod implements ModInitializer {
	public static final String MOD_ID = "sandevistan";

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}

	@Override
	public void onInitialize() {
		ModAttachments.init();
		ModItems.init();
		ModNetwork.init();
		SandevistanManager.init();
	}
}
