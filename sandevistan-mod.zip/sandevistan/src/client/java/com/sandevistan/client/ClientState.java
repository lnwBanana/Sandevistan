package com.sandevistan.client;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import com.sandevistan.net.StateS2C;

/** สถานะ Sandevistan ของผู้เล่นทุกคนที่ client รู้ (ได้จาก packet) */
public final class ClientState {
	public record Info(boolean active, float strain01, int cooldownTicks, boolean overheated, long activatedAt) {}

	private static final Map<UUID, Info> INFO = new HashMap<>();
	public static long clientTicks = 0;

	public static void update(StateS2C p) {
		Info old = INFO.get(p.player());
		long activatedAt = old == null ? 0 : old.activatedAt();
		if (p.active() && (old == null || !old.active())) activatedAt = clientTicks;
		INFO.put(p.player(), new Info(p.active(), p.strain01(), p.cooldownTicks(), p.overheated(), activatedAt));
	}

	public static Info get(UUID id) {
		return INFO.get(id);
	}

	public static boolean isActive(UUID id) {
		Info i = INFO.get(id);
		return i != null && i.active();
	}

	public static void clear() {
		INFO.clear();
	}

	private ClientState() {}
}
