package com.sandevistan.client.render;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

import com.mojang.blaze3d.vertex.PoseStack;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.state.CameraRenderState;
import net.minecraft.world.phys.Vec3;

import com.sandevistan.client.ClientState;

/**
 * Afterimage แบบ Sandevistan:
 *  - ทุก tick ที่ใช้งาน จะ "ถ่ายภาพ" ร่างผู้เล่น (render state ทั้งท่าทาง/เกราะ/ของในมือ)
 *  - ภาพเก่าจะค่อยๆ จางและไล่สีตามชุดสี ซ้อนทับกันเป็นแถบสีเรียงกัน
 */
public final class AfterimageRenderer {
	public static final int LIFETIME = 18; // ticks ที่ภาพค้างอยู่
	private static final float MAX_ALPHA = 0.62F;

	private record Snap(EntityRenderState state, long tick) {}

	private static final Map<UUID, Deque<Snap>> GHOSTS = new HashMap<>();

	/** เรียกทุก client tick */
	public static void tick(Minecraft mc) {
		if (mc.level == null) {
			GHOSTS.clear();
			return;
		}
		ClientState.clientTicks++;
		long now = ClientState.clientTicks;
		EntityRenderDispatcher dispatcher = mc.getEntityRenderDispatcher();

		for (AbstractClientPlayer player : mc.level.players()) {
			if (!ClientState.isActive(player.getUUID())) continue;
			EntityRenderState state = dispatcher.extractEntity(player, 1.0F);
			state.isInvisible = true; // ใช้ path โปร่งแสงของ vanilla
			if (state instanceof LivingEntityRenderState living) {
				living.isInvisibleToPlayer = false;
			}
			state.lightCoords = LightTexture.FULL_BRIGHT; // เรืองแสง ไม่โดนเงา
			state.nameTag = null;
			GHOSTS.computeIfAbsent(player.getUUID(), k -> new ArrayDeque<>()).addLast(new Snap(state, now));
		}

		Iterator<Map.Entry<UUID, Deque<Snap>>> it = GHOSTS.entrySet().iterator();
		while (it.hasNext()) {
			Deque<Snap> deque = it.next().getValue();
			while (!deque.isEmpty() && now - deque.peekFirst().tick() > LIFETIME) deque.removeFirst();
			if (deque.isEmpty()) it.remove();
		}
	}

	/** เรียกก่อน vanilla วาด entity */
	public static void render(WorldRenderContext context) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.level == null || GHOSTS.isEmpty()) return;

		CameraRenderState camState = context.worldState().cameraRenderState;
		Vec3 cam = camState.pos;
		PoseStack poseStack = context.matrices();
		SubmitNodeCollector collector = context.commandQueue();
		EntityRenderDispatcher dispatcher = mc.getEntityRenderDispatcher();

		boolean firstPerson = mc.options.getCameraType().isFirstPerson();
		float partial = mc.getDeltaTracker().getGameTimeDeltaPartialTick(false);
		float now = ClientState.clientTicks + partial;
		UUID self = mc.player == null ? null : mc.player.getUUID();

		try {
			for (Map.Entry<UUID, Deque<Snap>> entry : GHOSTS.entrySet()) {
				for (Snap snap : entry.getValue()) {
					float age = now - snap.tick();
					float life = Math.min(1.0F, Math.max(0.0F, age / LIFETIME)); // 0 ใหม่ -> 1 เก่า
					EntityRenderState st = snap.state();

					double dx = st.x - cam.x;
					double dy = st.y - cam.y;
					double dz = st.z - cam.z;

					// กันกล้อง first-person ไปอยู่ในหัวภาพล่าสุด
					if (firstPerson && entry.getKey().equals(self) && dx * dx + dy * dy + dz * dz < 2.6 * 2.6) continue;

					int alpha = (int) (255.0F * MAX_ALPHA * Math.pow(1.0F - life, 1.25));
					if (alpha < 6) continue;
					GhostTint.color = Palette.argb(alpha, Palette.sample(life));
					dispatcher.submit(st, camState, dx, dy, dz, poseStack, collector);
				}
			}
		} finally {
			GhostTint.color = 0;
		}
	}

	public static void clear() {
		GHOSTS.clear();
	}

	private AfterimageRenderer() {}
}
