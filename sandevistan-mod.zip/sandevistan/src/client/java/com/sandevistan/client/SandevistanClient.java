package com.sandevistan.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import com.sandevistan.SandevistanMod;
import com.sandevistan.client.hud.SandevistanHud;
import com.sandevistan.client.render.AfterimageRenderer;
import com.sandevistan.client.render.Palette;
import com.sandevistan.net.ActivateC2S;
import com.sandevistan.net.StateS2C;

public class SandevistanClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		KeyMapping.Category category = KeyMapping.Category.register(SandevistanMod.id("main"));
		KeyMapping activate = KeyBindingHelper.registerKeyBinding(
			new KeyMapping("key.sandevistan.activate", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, category));
		KeyMapping palette = KeyBindingHelper.registerKeyBinding(
			new KeyMapping("key.sandevistan.palette", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_B, category));

		ClientTickEvents.END_CLIENT_TICK.register(mc -> {
			while (activate.consumeClick()) {
				if (mc.player != null) ClientPlayNetworking.send(new ActivateC2S());
			}
			while (palette.consumeClick()) {
				Palette.next();
				if (mc.player != null) {
					mc.player.displayClientMessage(Component.literal("Afterimage palette: " + Palette.currentSet().name()), true);
				}
			}
			AfterimageRenderer.tick(mc);
		});

		ClientPlayNetworking.registerGlobalReceiver(StateS2C.TYPE, (payload, context) -> ClientState.update(payload));

		ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
			ClientState.clear();
			AfterimageRenderer.clear();
		});

		WorldRenderEvents.BEFORE_ENTITIES.register(AfterimageRenderer::render);

		HudElementRegistry.attachElementAfter(VanillaHudElements.HOTBAR, SandevistanMod.id("hud"), SandevistanHud::render);
	}
}
