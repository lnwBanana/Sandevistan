package com.sandevistan.client.hud;

import java.util.Random;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;

import com.sandevistan.ModAttachments;
import com.sandevistan.client.ClientState;
import com.sandevistan.client.render.Palette;
import com.sandevistan.item.SandevistanImplantItem;

/** HUD: เอฟเฟกต์จอตอนผ่าตัด, จอไซเบอร์ตอนใช้ Sandevistan, แถบ strain */
public final class SandevistanHud {

	public static void render(GuiGraphics g, DeltaTracker deltaTracker) {
		Minecraft mc = Minecraft.getInstance();
		LocalPlayer player = mc.player;
		if (player == null || mc.options.hideGui) return;

		int w = g.guiWidth();
		int h = g.guiHeight();
		float tick = ClientState.clientTicks + deltaTracker.getGameTimeDeltaPartialTick(false);

		if (player.isUsingItem() && player.getUseItem().getItem() instanceof SandevistanImplantItem) {
			surgeryOverlay(g, mc, player, w, h, tick);
		}

		if (!ModAttachments.isInstalled(player)) return;

		ClientState.Info info = ClientState.get(player.getUUID());
		boolean active = info != null && info.active();
		if (active) activeOverlay(g, w, h, tick, info);
		strainBar(g, mc, w, h, tick, info);
	}

	// ---------- ผ่าตัด ----------
	private static void surgeryOverlay(GuiGraphics g, Minecraft mc, LocalPlayer p, int w, int h, float tick) {
		float progress = 1.0F - p.getUseItemRemainingTicks() / (float) SandevistanImplantItem.SURGERY_TICKS;
		progress = Math.max(0, Math.min(1, progress));

		// หัวใจเต้น: ขอบจอแดงพัลส์ แรงขึ้นตามความคืบหน้า
		float beat = (float) Math.pow(Math.max(0, Math.sin(tick * (0.25F + progress * 0.25F))), 3);
		int a = (int) (50 + 110 * progress + 60 * beat);
		vignette(g, w, h, (int) (50 + 70 * progress), argb(Math.min(a, 220), 160, 0, 20));

		// มืดลงตอนใกล้จบ (เหมือนเกือบสลบ)
		if (progress > 0.7F) {
			g.fill(0, 0, w, h, argb((int) ((progress - 0.7F) / 0.3F * 120), 0, 0, 0));
		}

		// แถบความคืบหน้า
		int bw = 140;
		int x = w / 2 - bw / 2;
		int y = h - 72;
		g.fill(x - 1, y - 1, x + bw + 1, y + 7, 0xAA000000);
		g.fill(x, y, x + (int) (bw * progress), y + 6, argb(255, 255, (int) (60 + 180 * progress), (int) (80 + 160 * progress)));
		g.drawString(mc.font, "SURGERY IN PROGRESS", w / 2 - mc.font.width("SURGERY IN PROGRESS") / 2, y - 12, 0xFFFF4466, true);
	}

	// ---------- ตอนใช้ Sandevistan ----------
	private static void activeOverlay(GuiGraphics g, int w, int h, float tick, ClientState.Info info) {
		float age = ClientState.clientTicks - info.activatedAt();

		// แฟลชตอนเปิด
		float flash = Math.max(0, 1.0F - age / 8.0F);
		if (flash > 0) g.fill(0, 0, w, h, argb((int) (flash * 150), 190, 250, 255));

		// โทนสีฟ้าเข้มทั้งจอ
		g.fill(0, 0, w, h, argb(26, 0, 40, 130));

		// ขอบจอไล่สีตามชุดสี ค่อยๆ เปลี่ยน
		float t = (float) (Math.sin(tick * 0.08F) * 0.5 + 0.5);
		vignette(g, w, h, 70, Palette.argb(120, Palette.sample(t)));

		// เส้น glitch
		Random rnd = new Random((long) (tick * 0.6F) * 7919L);
		for (int i = 0; i < 5; i++) {
			int y = rnd.nextInt(h);
			int thickness = 1 + rnd.nextInt(3);
			int x1 = rnd.nextInt(w / 2);
			int x2 = x1 + w / 4 + rnd.nextInt(w / 2);
			g.fill(x1, y, Math.min(x2, w), y + thickness, Palette.argb(60, Palette.sample(rnd.nextFloat())));
		}

		// เส้น speed lines แนวนอนบางๆ
		for (int i = 0; i < 14; i++) {
			int y = rnd.nextInt(h);
			int len = 30 + rnd.nextInt(120);
			int x = rnd.nextBoolean() ? rnd.nextInt(w / 5) : w - len - rnd.nextInt(w / 5);
			g.fill(x, y, x + len, y + 1, argb(70, 220, 245, 255));
		}
	}

	// ---------- แถบ strain ----------
	private static void strainBar(GuiGraphics g, Minecraft mc, int w, int h, float tick, ClientState.Info info) {
		float strain = info == null ? 0 : info.strain01();
		boolean overheated = info != null && info.overheated();
		boolean active = info != null && info.active();
		int cooldown = info == null ? 0 : info.cooldownTicks();

		int bw = 110;
		int x = w / 2 - bw / 2;
		int y = h - 62;

		int r = (int) (40 + 215 * strain);
		int gr = (int) (230 - 190 * strain);
		int b = (int) (255 - 200 * strain);
		if (overheated && ((int) (tick / 4)) % 2 == 0) {
			r = 255; gr = 20; b = 20;
		}

		g.fill(x - 1, y - 1, x + bw + 1, y + 5, 0xAA000000);
		g.fill(x, y, x + (int) (bw * strain), y + 4, argb(255, r, gr, b));

		String label;
		int color;
		if (overheated) {
			label = "OVERHEAT";
			color = 0xFFFF3355;
		} else if (active) {
			label = "SANDEVISTAN";
			color = Palette.argb(255, Palette.sample((tick * 0.02F) % 1.0F));
		} else if (cooldown > 0) {
			label = "COOLING...";
			color = 0xFFFFCC44;
		} else {
			label = "SANDEVISTAN [READY]";
			color = 0xFF55E8FF;
		}
		g.drawString(mc.font, label, w / 2 - mc.font.width(label) / 2, y - 10, color, true);
	}

	// ---------- helper ----------
	/** ขอบจอไล่สีเข้ากลาง สีเดียว alpha ลดลงเป็นขั้น */
	private static void vignette(GuiGraphics g, int w, int h, int edge, int color) {
		int baseAlpha = (color >>> 24) & 255;
		int rgb = color & 0xFFFFFF;
		int c0 = (baseAlpha << 24) | rgb;
		int cz = rgb;
		g.fillGradient(0, 0, w, edge, c0, cz);
		g.fillGradient(0, h - edge, w, h, cz, c0);
		int step = 4;
		for (int i = 0; i < edge; i += step) {
			int a = (int) (baseAlpha * (1.0F - i / (float) edge));
			int c = (a << 24) | rgb;
			g.fill(i, edge, i + step, h - edge, c);
			g.fill(w - i - step, edge, w - i, h - edge, c);
		}
	}

	private static int argb(int a, int r, int gr, int b) {
		return (Math.max(0, Math.min(255, a)) << 24) | (clamp(r) << 16) | (clamp(gr) << 8) | clamp(b);
	}

	private static int clamp(int v) {
		return Math.max(0, Math.min(255, v));
	}

	private SandevistanHud() {}
}
