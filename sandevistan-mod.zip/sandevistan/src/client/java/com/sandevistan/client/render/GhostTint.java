package com.sandevistan.client.render;

/** สีที่ mixin จะยัดให้ตอนวาด afterimage (0 = วาดปกติ) */
public final class GhostTint {
	public static int color = 0;

	private GhostTint() {}
}
