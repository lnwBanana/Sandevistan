package com.sandevistan.client.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

import com.sandevistan.client.render.GhostTint;

/** ตอนวาด afterimage: ใส่สี ARGB ของเราแทนสี tint เดิม + ปิด layer (เกราะ/ผ้าคลุม) ไม่ให้ทึบ */
@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {
	@ModifyArg(
		method = "submit(Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/CameraRenderState;)V",
		at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/SubmitNodeCollector;submitModel"),
		index = 6,
		require = 0
	)
	private int sandevistan$tint(int original) {
		return GhostTint.color != 0 ? GhostTint.color : original;
	}

	@Inject(method = "shouldRenderLayers", at = @At("HEAD"), cancellable = true, require = 0)
	private void sandevistan$noLayers(LivingEntityRenderState state, CallbackInfoReturnable<Boolean> cir) {
		if (GhostTint.color != 0) cir.setReturnValue(false);
	}
}
