package com.sandevistan.client.render;

/** ชุดสีของ afterimage: t=0 (ใหม่สุด) -> t=1 (เก่าสุด) ไล่สีเรียงต่อกัน */
public final class Palette {
	public record Set(String name, int[][] stops) {}

	public static final Set[] ALL = {
		// สไตล์ Edgerunners: ฟ้า -> น้ำเงิน -> ม่วง -> ชมพู -> แดง -> ส้ม -> เหลือง
		new Set("Edgerunner", new int[][] {
			{0, 235, 255}, {60, 110, 255}, {150, 70, 255}, {255, 50, 200}, {255, 60, 80}, {255, 150, 40}, {255, 230, 60}
		}),
		new Set("Rainbow", new int[][] {
			{255, 40, 60}, {255, 160, 30}, {255, 240, 50}, {60, 255, 100}, {40, 220, 255}, {90, 80, 255}, {220, 60, 255}
		}),
		new Set("Solar", new int[][] {
			{255, 250, 160}, {255, 210, 50}, {255, 130, 30}, {255, 50, 50}, {160, 20, 70}
		}),
		new Set("Ice", new int[][] {
			{255, 255, 255}, {150, 240, 255}, {40, 190, 255}, {50, 80, 255}, {100, 40, 200}
		})
	};

	public static int current = 0;

	public static void next() {
		current = (current + 1) % ALL.length;
	}

	public static Set currentSet() {
		return ALL[current];
	}

	/** @return {r,g,b} */
	public static int[] sample(float t) {
		int[][] s = currentSet().stops();
		t = Math.max(0f, Math.min(1f, t)) * (s.length - 1);
		int i = Math.min((int) t, s.length - 2);
		float f = t - i;
		return new int[] {
			(int) (s[i][0] + (s[i + 1][0] - s[i][0]) * f),
			(int) (s[i][1] + (s[i + 1][1] - s[i][1]) * f),
			(int) (s[i][2] + (s[i + 1][2] - s[i][2]) * f)
		};
	}

	public static int argb(int alpha, int[] rgb) {
		return (alpha & 255) << 24 | rgb[0] << 16 | rgb[1] << 8 | rgb[2];
	}

	private Palette() {}
}
